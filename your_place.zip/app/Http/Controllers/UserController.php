<?php

namespace App\Http\Controllers;

use App\Events\ChatEvent;
use App\Models\Chat;
use App\Models\Contact;
use App\Models\Post;
use App\Models\Save;
use App\Models\Share;
use Carbon\Carbon;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Mail\ForgetPassword;
use Tymon\JWTAuth\Facades\JWTAuth;


class UserController extends Controller
{

    // user register
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|max:100|unique:users',
        ]);
        if($validator->fails()){
            return response()->json([
                'status' => 0 ,
                'message' => 'failed , phone must be unique and required ',
            ]);
        }

        User::create([
            'name' => $request->name ,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'phone' => $request->phone ,
            'login_type' => $request->login_type ,
            'code' => 4444*1
        ]);

        return response()->json([
                'status' => 1 ,
                'message' => 'user registered successfully',
        ]);

    }


    // unique email
    public function uniqueEmail(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:100|unique:users',
        ]);
        if($validator->fails()){
            return response()->json([
                'status' => 0 ,
                'message' => 'The email has already been taken',
            ]);
        }
        return response()->json([
            'status' => 1 ,
            'message' => 'email correct and unique',
        ]);
    }


    // unique phone number
    public function uniquePhone(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone' => 'required|unique:users,phone',
        ]);
        if($request->phone == null)
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'The email is required',
            ]);
        }
        elseif($validator->fails()){
            return response()->json([
                'status' => 0 ,
                'message' => 'The email has already been taken',
            ]);
        }
        return response()->json([
            'status' => 1 ,
            'message' => 'email correct and unique',
        ]);
    }


    // user login
    public function login(Request $request)
    {
        $credentials  =  $request->only('phone', 'password');
        $user = User::where('phone',$request->phone)->first();

        if (! $token = auth()->attempt($credentials))
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'Unauthorized',
                'userId' => 0*1 ,
                'userName' => null ,
                'userEmail' =>null ,
                'userPhone' => null,
                'userLoginType' => null,
                'activate' => 0*1
            ]);
        }
        elseif($user->activate == 2)
        {
            return response()->json([
                'status' => 2 ,
                'message' => 'user did not activate yet',
                'userId' => 0*1 ,
                'userName' => null ,
                'userEmail' =>null ,
                'userPhone' => null,
                'userLoginType' => null,
                'activate' => 2*1
            ]);
        }
            return $this->createNewToken($token);

     }


    // login by email only
    public function loginbyemail(Request $request)
    {

        $user = User::where('email',$request->email)->first();
        if($user && $user->login_type == $request->login_type)
        {
            return response()->json([
                'status' => 1 ,
                'message' => 'email is correct',
                'userId' => $user->id ,
                'userName' => $user->name ,
                'userEmail' =>$user->email ,
                'userPhone' => $user->phone ,
                'userLoginType' => $user->login_type,
                'activate' =>$user->activate
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'failed to login',
                'userId' => 0*1 ,
                'userName' => null ,
                'userEmail' =>null ,
                'userPhone' => null,
                'userLoginType' => null,
                'activate' => 4*1
            ]);
        }
    }


    // send email for user when forget password
    public function forgotPassword(Request $request)
    {
        $user = User::where('email',$request->email)->first();
        if($user){
            Mail::to($user->email)->send(new ForgetPassword());
            return response()->json([
                'status' => 1 ,
                'message' => 'please check your email to reset passoword',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'error,failed to send code',
            ]);
        }

    }


    // get code from user to verify his phone
    public function getCode(Request $request)
    {
        $user = User::where('phone',$request->phone)->first();

        if(!$user || $user->phone == null )
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'user not found',
                'userId' => 0*1 ,
                'userName' => null ,
                'userEmail' =>null ,
                'userPhone' => null,
                'userLoginType' => null,
                'activate' =>0*1
            ]);
        }
        elseif ($user->code == null || $user->code !== $request->code)
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'code not found or correct',
                'userId' => 0*1 ,
                'userName' => null ,
                'userEmail' =>null ,
                'userPhone' => null,
                'userLoginType' => null,
                'activate' =>0*1
            ]);
        }
        elseif($user && $user->code == $request->code)
        {
            $user->email_verified_at = Carbon::now();
            $user->activate = 1*1 ;
            $user->code = null ;
            $user->save() ;
            return response()->json([
                'status' => 1 ,
                'message' => 'success',
                'userId' => $user->id*1 ,
                'userName' => $user->name ,
                'userEmail' =>$user->email ,
                'userPhone' => $user->phone ,
                'userLoginType' => $user->login_type,
                'activate' => 1*1
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'error',
                'userId' => 0*1 ,
                'userName' => null ,
                'userEmail' =>null ,
                'userPhone' => null,
                'userLoginType' => null,
                'activate' =>0*1
            ]);
        }
    }


    // reset new password
    public function reset(Request $request)
    {
        $user = User::where('phone', $request->phone)->first();

        if (!$user) {
            return response()->json([
                'status' => 0,
                'message' => 'user not found ',
            ]);
        }
        elseif ($request->phone == null)
        {
            return response()->json([
                'status' => 0,
                'message' => 'incorrect phone number',
            ]);
        }

        elseif ($request->password == null)
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'please enter password ',
            ]);
        }
        elseif ($user && $request->password !== null && $request->phone !== null )
        {
                $user->password = Hash::make($request->password);
                $user->code = null;
                $user->save();
                return response()->json([
                    'status' => 1 ,
                    'message' => 'password changed successfully',
                ]);
        }
        else
        {
            return response()->json([
                'status' => 1 ,
                'message' => 'failed to reset password',
            ]);
        }
    }


    // upload user avatar
    public function uploadAvatar(Request $request)
    {
        $user = User::find($request->user_id);
        $file = $request->file('avatar');

        if(!$user || $request->user_id == null )
        {
            return response()->json([
                'status' => 0,
                'message' => 'user not found ',
            ]);
        }
        elseif ($file == null )
        {
            return response()->json([
                'status' => 0,
                'message' => 'avatar not found ',
            ]);
        }
        elseif($user && $file)
        {
            $extension = $file->getClientOriginalExtension();
            $path = $file->store('public');
            $truepath = substr($path, 7);

            $user->avatar = URL::to('/') . '/storage/' . $truepath ;
            $user->save();

            return response()->json([
                'status' => 1 ,
                'message' => 'image changed successfully',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'failed to upload image',
            ]);

        }
    }


    // edit user name
    public function editName(Request $request)
    {
        $user = User::find($request->user_id);

        if(!$user || $request->user_id == null )
        {
            return response()->json([
                'status' => 0,
                'message' => 'user not found ',
            ]);
        }
        elseif ($request->name == null)
        {
            return response()->json([
                'status' => 0,
                'message' => 'name is required ',
            ]);
        }
        elseif($user && $request->name !== null)
        {
            $user->name = $request->name ;
            $user->save();

            return response()->json([
                'status' => 1 ,
                'message' => 'Name changed successfully',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'failed, invalid id',
            ]);

        }
    }

    // edit user phone
    public function editPassword(Request $request)
    {
        $user = User::find($request->user_id);

        if (!$user || $request->user_id == null)
        {
                return response()->json([
                    'status' => 0 ,
                    'message' => 'user not found',
                ]);
        }
        elseif($request->old_password == null || !Hash::check($request->old_password, $user->password))
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'The old password is not correct',
            ]);
        }
        elseif ($request->new_password == null)
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'failed, please enter new password',
            ]);
        }
        elseif ($user && Hash::check($request->old_password, $user->password) && $request->new_password !== null)
        {
            $user->password = bcrypt($request->input('new_password'));
            $user->save();
            return response()->json([
                'status' => 1 ,
                'message' => 'Password changed successfully',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'error',
            ]);
        }

    }


    // get code from user to verify his phone
    public function editPhone(Request $request)
    {

        $user = User::find($request->user_id);

        if(!$user || $request->user_id == null )
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'user not found',
            ]);
        }
        elseif ($request->phone == null)
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'please enter your phone',
            ]);
        }
        elseif ( $user->code !== $request->code || $request->code == null )
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'failed, incorrect code',
            ]);
        }
        elseif ( $user && $user->code == $request->code && $request->phone !== null)
        {
            $user->phone = $request->phone ;
            $user->email_verified_at = Carbon::now();
            $user->activate = 1*1 ;
            $user->code = null ;
            $user->save() ;

            return response()->json([
                'status' => 1 ,
                'message' => 'phone changed',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'error',
            ]);
        }
    }



    //  add to saved posts
    public function addToSaved(Request $request)
    {
        $user = User::find($request->user_id) ;
        $post = Post::find($request->post_id) ;
        $saved = Save::where([['user_id',$request->user_id],['post_id',$request->post_id]])->first();

        if(!$user || $request->user_id == null )
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'user not found',
            ]);
        }
        elseif(!$post || $request->post_id == null )
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'post not found',
            ]);
        }
        elseif ($saved)
        {
            $saved->delete();
            return response()->json([
                'status' => 1 ,
                'message' => 'post removed form saved',
            ]);
        }
        elseif(!$saved && $user && $post && $post->activate == 1)
        {
                Save::firstOrCreate([
                'user_id'  => $request->user_id,
                'post_id'  => $request->post_id,
            ]);

            return response()->json([
                'status' => 1 ,
                'message' => 'post add to saved',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'error',
            ]);
        }

    }


    // contact us
    public function contactUs(Request $request)
    {
        $user = User::find($request->user_id) ;
        if ($user)
        {
            Contact::create([
               'email' => $request->email ,
               'subject' => $request->subject ,
               'message' => $request->message ,
               'user_id' => $request->user_id,
                'replied' => 0*1
            ]);
            return response()->json([
                'status' => 1 ,
                'message' => 'thanks for your msg, we will reply soon',
            ]);
        }
        else
        {
            return response()->json([
                'status' => 0 ,
                'message' => 'failed to send message',
            ]);
        }
    }


    // get all chats that belongs to user
    public function getChats(Request $request)
    {
        $user = User::find($request->user_id);
        $chats = Chat::where('user_id',$request->user_id)->select('receiver_id')
            ->distinct()->get();

        $arr=[];
       foreach ($chats as $chat)
        {
            $receiveres[] = $chat->receiver_id;
            $receiver = User::find($chat->receiver_id);
            $message = Chat::where('user_id',$request->user_id)->where('receiver_id',$receiver->id)->select('message','created_at')->first();
            $data = ["id" => $receiver->id,"name" => $receiver->name,"avatar" => $receiver->avatar,"message" => $message];
             array_push($arr , $data);

               }
        echo json_encode($arr) ;


    }


    // user token
    protected function createNewToken($token)
    {
       $user = auth()->user() ;
        return response()->json([
            'status' => 1 ,
            'message' => 'user loggined successfully',
            'userId' => $user->id*1 ,
            'userName' => $user->name ,
            'userEmail' =>$user->email ,
            'userPhone' => $user->phone ,
            'userLoginType' => $user->login_type ,
            'activate' => $user->activate*1
        ]);
    }


    // user logout
    public function logout()
    {
        auth()->logout();
        return response()->json([
            'status' => 1 ,
            'message' => 'User successfully signed out',
        ]);
    }


}
